#include "shell.h"

int main() {
    run_shell();
    return 0;
}
