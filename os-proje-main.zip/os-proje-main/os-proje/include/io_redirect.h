#ifndef IO_REDIRECT_H
#define IO_REDIRECT_H

void redirect_input(char *file);  // Girdi yönlendirme
void redirect_output(char *file); // Çıktı yönlendirme

#endif
