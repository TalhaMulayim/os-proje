// Ahmet Kürşat Sonkur
// Mustafa Köslü
// Talha Mülayim
#include "shell.h"

int main() {
    run_shell();
    return 0;
}
