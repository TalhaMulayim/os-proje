#ifndef COMMAND_H
#define COMMAND_H

void execute_command(char *command); 
void execute_pipe(char *commands);
void execute_sequential(char *commands) ;

#endif
