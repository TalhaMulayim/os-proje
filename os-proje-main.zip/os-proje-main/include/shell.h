#ifndef SHELL_H
#define SHELL_H

void run_shell();      // Kabuk döngüsünü çalıştır
void display_prompt(); // Prompt göster
void read_command(char *command); // Kullanıcıdan komut oku

#endif
